
#include <stdio.h>
#include <raylib.h>

#include "interface.h"
#include <state.h>

State state;

void update_and_draw() {
	state_update(state);
	interface_draw_frame(state);
}

int main() {
	state = state_create();
	interface_init();

	// Η κλήση αυτή καλεί συνεχόμενα την update_and_draw μέχρι ο χρήστης να κλείσει το παράθυρο
	start_main_loop(update_and_draw);

	interface_close();

	return 0;
}



